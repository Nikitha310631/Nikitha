import { useRef } from "react";
const Addtodo = (props:any) => {
  const inputval:any = useRef(null);
    const addreminder = ()=>{
      let txt = inputval.current.value;
      console.log(txt);
props.newitem(txt);
    }
  return (
    <div>
     <input ref={inputval} type="text" onBlur={addreminder}/>
    </div>
  )
}

export default Addtodo
