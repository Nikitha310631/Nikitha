import { Component } from 'react'

export default class Classcomp extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
