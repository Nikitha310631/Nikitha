import {useState} from 'react'

const Funccomp = () => {
      const [user,setUser] = useState();
    const txt = ()=>{
      
    }
  return (
    <div>
      {user}
    </div>
  )
}

export default Funccomp
