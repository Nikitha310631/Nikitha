import Deltodo from "./Deltodo"
const Displaytodo = (props:any) => {
  
  return (
    <div>{props.data!==''?
        <ol>
      {props.data.map((i:any,index:number)=><li key={index}><Deltodo del={props.delitem} pos={i.id} item={i.name}/></li>)}
      </ol>:''}
    </div>
  )
}

export default Displaytodo
