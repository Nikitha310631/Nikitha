import React from 'react'

const Menu = (props:any) => {
    const getLink = (e:any)=>{
        console.log(e.target.value)
props.clickmenu(e.target.value);
    }
  return (
    <div>
     <input type="button" name="displaytodo" id="displaytodo" value="Todo" onClick={getLink}/>
     <input type="button" name="addnew" id="addnew" value="New" onClick={getLink}/>
    </div>
  )
}

export default Menu
