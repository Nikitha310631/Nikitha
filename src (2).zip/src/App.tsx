import { useState,useEffect,useId } from 'react';
import './App.css';
import Menu from './Menu';
import Displaytodo from './Displaytodo';
import Addtodo from './Addtodo';
import { UserProvider } from './UserContext';
//const url = "mongodb://atlas-sql-685a7a57dba0d45ecf46fd43-w05ks5.a.query.mongodb.net/todo?ssl=true&authSource=admin";
const url = "http://localhost:3000/todo/";
const App = ()=>{
   const [link,setLink] = useState("Todo");
const [todo,setTodo] = useState([{}]);
useEffect(()=>{
  fetch(url)
  .then((i:any)=>i.json()
.then((data:any)=>setTodo(data)));
},[]);

 
const clickmenu = (txt:string)=>{
setLink(txt);
}
const newitem = (txt:any)=>{

setTodo([...todo,{id:useId,"name":txt}]);
fetch(url,{"headers":{"Content-Type":"application/json"},"method":"POST","body":JSON.stringify({id:useId,"name":txt})})
.then((res:any)=>res.json()
.then((data:any)=>{console.log(data)}));
}
const delitem = (pos:any)=>{
  console.log("pos",pos);
setTodo([...todo.filter((i:any,index:any)=>i.id!==pos)]);
fetch(`${url+pos}`,{"headers":{"accept":"application/json","content-type":"application/json"},"method":"DELETE"})
.then((i:any)=>i.json()
.then((data:any)=>{console.log(data)}));
}
  return (
     <UserProvider>
   <Menu clickmenu = {clickmenu}/>
   {link=="Todo"?<Displaytodo delitem={delitem} data = {todo}/>:''}
    {link=="New"?<Addtodo newitem = {newitem}/>:''}

   </UserProvider>
  )
}

export default App
