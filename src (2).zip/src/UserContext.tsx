// UserContext.tsx
import React, { createContext, useState, useContext } from 'react';

// Define a type for the user
type User = {
  name: string;
} | null;

// Define a type for the context value
interface UserContextType {
  user: User;
  setUser: (user: User) => void;
}

// Create context with default value
const UserContext = createContext<UserContextType | undefined>(undefined);

// Provider component
export const UserProvider: React.FC<{ children : any }> = ({ children }) => {
  const [user, setUser] = useState<User>(null);

  return (
    <UserContext.Provider value={{ user, setUser }}>
      {children}
    </UserContext.Provider>
  );
};

// Custom hook for easier access
export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};
