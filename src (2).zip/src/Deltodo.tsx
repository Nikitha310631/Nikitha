import React from 'react'

const Deltodo = (props:any) => {
    const del1 = ()=>{
      console.log("deldet",props.pos)
props.del(props.pos);
    }
  return (
    <div>
    
      {props.item} <input type="button" onClick={del1} value="Delete"/>
    </div>
  )
}

export default Deltodo
